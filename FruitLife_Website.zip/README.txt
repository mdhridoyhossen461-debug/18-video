# Fruit Life Website

## Publish with GitHub Pages
1. Create a GitHub account.
2. Create a new public repository, for example `fruitlife`.
3. Upload `index.html`.
4. Open Settings → Pages.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for the GitHub Pages URL.

## Add Adsterra
After your website is approved by Adsterra:
1. Create an ad unit in the Adsterra publisher dashboard.
2. Copy the provided ad code.
3. Open `index.html`.
4. Replace `Ad space` inside the marked `PASTE YOUR ADSTERRA AD CODE HERE` areas with the code.
5. Upload the updated file again.

Do not put ads on pages containing prohibited or misleading content, and follow Adsterra's publisher rules.
